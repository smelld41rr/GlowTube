# Asset provenance

The PNG icons at icons/icon16.png, icon32.png, icon48.png and icon128.png are the existing original geometric Vistara icons copied from the parent Vistara project, under its MIT license (included as LICENSE.txt).

This standalone project uses local CSS gradients and installed/system fonts. It includes no remote wallpaper or scripts. Uploaded wallpapers are user-owned local data and are excluded from exported archives. No parent-project scene SVG library is used in this build.
